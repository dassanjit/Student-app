export const environment = {
    baseApiUrl: 'https://localhost:7212/'
};
