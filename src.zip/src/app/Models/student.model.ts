export interface Student {
    id: number,
    name: string;
    email: string;
    phone: number;
    department: string;
}